from django.shortcuts import render
from .models import Product
from .forms import ProductForm
from django.http import HttpResponseRedirect


def index(r):
    prd = Product.objects.all()
    return render(r,'curdapp/index.html',{'prd':prd})


def insert(r):
    form = ProductForm()
    if r.method=='POST':
        form = ProductForm(r.POST)
        if form.is_valid():
            form.save(commit=True)

        return HttpResponseRedirect('/')

    return render(r,'curdapp/insert.html',{'form':form})


def delete(r,id):
    class Meta:
        prd = Product.objects.get(id=id)
        prd.delete()
    return HttpResponseRedirect('/')


def update(r,id):
    prd = Product.objects.get(id=id)

    if r.method == 'POST':
        form = ProductForm(r.POST, instance=prd)
        if form.is_valid():
            form.save(commit=True)
        return HttpResponseRedirect('/')

    return render(r, 'curdapp/update.html', {'prd': prd})